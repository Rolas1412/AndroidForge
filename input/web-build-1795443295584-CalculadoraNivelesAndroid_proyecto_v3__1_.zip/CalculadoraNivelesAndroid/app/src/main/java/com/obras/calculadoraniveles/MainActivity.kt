package com.obras.calculadoraniveles

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { CalculatorScreen() } }
    }
}

data class PointLevel(val distance: Double, val level: Double)

data class Calculation(
    val name: String,
    val a: Double,
    val b: Double,
    val distance: Double,
    val excavationA: Double,
    val excavationB: Double,
    val finalA: Double,
    val finalB: Double,
    val difference: Double,
    val slopePercent: Double,
    val points: List<PointLevel>,
    val pointMode: String = "single"
)

private fun fmt(value: Double) = String.format(Locale.US, "%.3f", value)

@Composable
fun CalculatorScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var workName by remember { mutableStateOf("Trabajo nuevo") }
    var aText by remember { mutableStateOf("100.000") }
    var bText by remember { mutableStateOf("98.500") }
    var distanceText by remember { mutableStateOf("20.000") }
    var excavationAText by remember { mutableStateOf("0.300") }
    var excavationBText by remember { mutableStateOf("0.300") }
    var intermediateText by remember { mutableStateOf("10.000") }
    var pointMode by remember { mutableStateOf("single") }
    var pointCountText by remember { mutableStateOf("4") }
    var manualDistancesText by remember { mutableStateOf("5.000, 10.000, 15.000") }
    var result by remember { mutableStateOf<Calculation?>(null) }
    var error by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(loadSaved(context)) }
    var showSaved by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val latestResult by rememberUpdatedState(result)

    val excelLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri -> if (uri != null) {
        try { latestResult?.let { writeExcel(context, uri, it) }; message = "Archivo Excel exportado." }
        catch (e: Exception) { message = "No se pudo exportar Excel: ${e.message}" }
    } }
    val pdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri -> if (uri != null) {
        try { latestResult?.let { writePdf(context, uri, it) }; message = "Archivo PDF exportado." }
        catch (e: Exception) { message = "No se pudo exportar PDF: ${e.message}" }
    } }

    fun calculate(): Calculation? {
        val a = aText.toDoubleOrNull()
        val b = bText.toDoubleOrNull()
        val d = distanceText.toDoubleOrNull()
        val ea = excavationAText.toDoubleOrNull()
        val eb = excavationBText.toDoubleOrNull()
        if (a == null || b == null || d == null || ea == null || eb == null) {
            error = "Revisa los datos: todos los campos deben contener números."
            return null
        }
        if (d <= 0.0) {
            error = "La distancia horizontal debe ser mayor que cero."
            return null
        }
        val fa = a - ea
        val fb = b - eb
        val delta = fb - fa
        val slope = delta / d * 100.0
        val points: List<PointLevel> = when (pointMode) {
            "uniform" -> {
                val count = pointCountText.toIntOrNull()
                if (count == null || count < 1 || count > 500) {
                    error = "Indica entre 1 y 500 puntos intermedios."
                    return null
                }
                (1..count).map { i ->
                    val x = d * i.toDouble() / (count + 1).toDouble()
                    PointLevel(x, fa + delta * (x / d))
                }
            }
            "manual" -> {
                val raw = manualDistancesText.split(Regex("[,;\\s]+")) .filter { it.isNotBlank() }
                if (raw.isEmpty()) {
                    error = "Escribe al menos una distancia manual desde A."
                    return null
                }
                val distances = raw.mapNotNull { it.toDoubleOrNull() }
                if (distances.size != raw.size) {
                    error = "Hay una distancia manual que no es un número válido."
                    return null
                }
                if (distances.any { it <= 0.0 || it >= d }) {
                    error = "Cada distancia manual debe ser mayor que 0 y menor que la distancia total."
                    return null
                }
                if (distances.distinct().size != distances.size) {
                    error = "No repitas distancias manuales."
                    return null
                }
                distances.sorted().map { x -> PointLevel(x, fa + delta * (x / d)) }
            }
            else -> {
                val x = intermediateText.toDoubleOrNull()
                if (x == null || x <= 0.0 || x >= d) {
                    error = "La distancia del punto debe ser mayor que 0 y menor que la distancia total."
                    return null
                }
                listOf(PointLevel(x, fa + delta * (x / d)))
            }
        }
        error = ""
        return Calculation(workName.ifBlank { "Trabajo sin nombre" }, a, b, d, ea, eb,
            fa, fb, delta, slope, points, pointMode)
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Calculadora de niveles", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Cotas, excavación, pendiente y puntos intermedios", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

        OutlinedTextField(workName, { workName = it }, label = { Text("Nombre del trabajo / obra") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Text("DATOS DE ENTRADA", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        NumberField("Cota conocida A (m)", aText) { aText = it }
        NumberField("Cota conocida B (m)", bText) { bText = it }
        NumberField("Distancia horizontal A–B (m)", distanceText) { distanceText = it }
        NumberField("Excavación en A (m)", excavationAText) { excavationAText = it }
        NumberField("Excavación en B (m)", excavationBText) { excavationBText = it }

        HorizontalDivider()
        Text("PUNTOS INTERMEDIOS", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = pointMode == "single", onClick = { pointMode = "single"; result = null }, label = { Text("Un punto") })
            FilterChip(selected = pointMode == "uniform", onClick = { pointMode = "uniform"; result = null }, label = { Text("Distancias iguales") })
            FilterChip(selected = pointMode == "manual", onClick = { pointMode = "manual"; result = null }, label = { Text("Manuales") })
        }
        when (pointMode) {
            "uniform" -> {
                NumberField("Cantidad de puntos intermedios", pointCountText) { pointCountText = it }
                Text("Se distribuyen a intervalos iguales entre A y B, sin incluir los extremos.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            "manual" -> {
                OutlinedTextField(manualDistancesText, { manualDistancesText = it; result = null }, label = { Text("Distancias desde A (m)") }, placeholder = { Text("Ej. 3.5, 8, 12.5") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Text("Separa las distancias con coma, punto y coma o espacios. Todas se miden horizontalmente desde A y se ordenan automáticamente.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            else -> {
                NumberField("Distancia del punto desde A (m)", intermediateText) { intermediateText = it }
                Text("Indica una distancia horizontal medida desde A.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Button(onClick = { result = calculate(); message = "" }, modifier = Modifier.fillMaxWidth()) {
            Text("Calcular niveles")
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)

        result?.let { r ->
            Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("RESULTADOS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    ResultRow("Nivel terminado en A", "${fmt(r.finalA)} m")
                    ResultRow("Nivel terminado en B", "${fmt(r.finalB)} m")
                    ResultRow("Desnivel A → B", "${fmt(r.difference)} m")
                    ResultRow("Pendiente", "${fmt(r.slopePercent)} %")
                    ResultRow("Sentido", when {
                        r.difference > 0 -> "Ascendente de A hacia B"
                        r.difference < 0 -> "Descendente de A hacia B"
                        else -> "Sin pendiente"
                    })
                    HorizontalDivider()
                    Text("PERFIL LONGITUDINAL", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    ProfileChart(r)
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        LegendDot(Color(0xFFE58A28), "Cota original")
                        LegendDot(Color(0xFF269B62), "Perfil excavado")
                    }
                    HorizontalDivider()
                    Text("TABLA DE NIVELES INTERMEDIOS", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Punto", fontWeight = FontWeight.Bold)
                        Text("Distancia (m)", fontWeight = FontWeight.Bold)
                        Text("Nivel (m)", fontWeight = FontWeight.Bold)
                    }
                    r.points.forEachIndexed { index, point ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${index + 1}")
                            Text(fmt(point.distance))
                            Text(fmt(point.level), fontWeight = FontWeight.SemiBold)
                        }
                    }
                    HorizontalDivider()
                    Button(onClick = {
                        val fresh = calculate()
                        if (fresh != null) {
                            saved = saved + fresh
                            persistSaved(context, saved)
                            message = "Trabajo guardado en este dispositivo."
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Guardar trabajo") }
                    OutlinedButton(onClick = { excelLauncher.launch(safeFileName(r.name) + ".xlsx") }, modifier = Modifier.fillMaxWidth()) {
                        Text("Exportar a Excel (.xlsx)")
                    }
                    OutlinedButton(onClick = { pdfLauncher.launch(safeFileName(r.name) + ".pdf") }, modifier = Modifier.fillMaxWidth()) {
                        Text("Exportar a PDF")
                    }
                }
            }
        }

        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
        OutlinedButton(onClick = { showSaved = !showSaved }, modifier = Modifier.fillMaxWidth()) {
            Text(if (showSaved) "Ocultar trabajos guardados" else "Ver trabajos guardados (${saved.size})")
        }
        if (showSaved) {
            Text("TRABAJOS GUARDADOS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (saved.isEmpty()) Text("Todavía no hay trabajos guardados.")
            saved.forEachIndexed { index, item ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(item.name, fontWeight = FontWeight.Bold)
                        Text("A: ${fmt(item.a)} m | B: ${fmt(item.b)} m")
                        Text("Pendiente: ${fmt(item.slopePercent)} % | ${item.points.size} punto(s)")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = {
                                workName = item.name
                                aText = fmt(item.a); bText = fmt(item.b); distanceText = fmt(item.distance)
                                excavationAText = fmt(item.excavationA); excavationBText = fmt(item.excavationB)
                                pointMode = item.pointMode
                                if (item.pointMode == "single" && item.points.isNotEmpty()) intermediateText = fmt(item.points.first().distance)
                                if (item.pointMode == "uniform") pointCountText = item.points.size.toString()
                                if (item.pointMode == "manual") manualDistancesText = item.points.joinToString(", ") { fmt(it.distance) }
                                result = item
                                showSaved = false
                            }) { Text("Abrir") }
                            TextButton(onClick = {
                                saved = saved.filterIndexed { i, _ -> i != index }
                                persistSaved(context, saved)
                            }) { Text("Eliminar", color = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
        }
        Text("Los trabajos se guardan localmente en este teléfono. Usa punto o coma decimal.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(10.dp).background(color, CircleShape))
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun ProfileChart(c: Calculation) {
    val originalA = c.a
    val originalB = c.b
    val minY = minOf(originalA, originalB, c.finalA, c.finalB) - 0.25
    val maxY = maxOf(originalA, originalB, c.finalA, c.finalB) + 0.25
    val spanY = (maxY - minY).coerceAtLeast(0.5)
    Canvas(Modifier.fillMaxWidth().height(220.dp).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f), RoundedCornerShape(10.dp))) {
        val left = 48f; val right = size.width - 14f; val top = 16f; val bottom = size.height - 30f
        val plotW = right - left; val plotH = bottom - top
        fun px(x: Double) = left + (x / c.distance).toFloat() * plotW
        fun py(y: Double) = bottom - ((y - minY) / spanY).toFloat() * plotH
        val grid = Color.Gray.copy(alpha = 0.35f)
        for (i in 0..4) {
            val yy = top + plotH * i / 4f
            drawLine(grid, Offset(left, yy), Offset(right, yy), 1f)
        }
        drawLine(grid, Offset(left, top), Offset(left, bottom), 1f)
        drawLine(grid, Offset(left, bottom), Offset(right, bottom), 1f)
        val original = Path().apply { moveTo(px(0.0), py(originalA)); lineTo(px(c.distance), py(originalB)) }
        val finished = Path().apply { moveTo(px(0.0), py(c.finalA)); lineTo(px(c.distance), py(c.finalB)) }
        drawPath(original, Color(0xFFE58A28), style = Stroke(width = 4f))
        drawPath(finished, Color(0xFF269B62), style = Stroke(width = 5f))
        c.points.forEach { point ->
            val x = px(point.distance); val y = py(point.level)
            drawLine(Color(0xFF269B62).copy(alpha = 0.45f), Offset(x, top), Offset(x, bottom), 1.5f)
            drawCircle(Color(0xFF269B62), 5f, Offset(x, y))
        }
        drawCircle(Color(0xFF269B62), 5f, Offset(px(0.0), py(c.finalA)))
        drawCircle(Color(0xFF269B62), 5f, Offset(px(c.distance), py(c.finalB)))
        drawIntoCanvas { canvas ->
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.DKGRAY; textSize = 10f
            }
            canvas.nativeCanvas.drawText(String.format(Locale.US, "%.2f", maxY), 3f, top + 4f, paint)
            canvas.nativeCanvas.drawText(String.format(Locale.US, "%.2f", minY), 3f, bottom, paint)
            canvas.nativeCanvas.drawText("A / 0 m", left, size.height - 8f, paint)
            canvas.nativeCanvas.drawText("B / ${fmt(c.distance)} m", right - 65f, size.height - 8f, paint)
        }
    }
}

@Composable
private fun NumberField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = { onValueChange(it.replace(',', '.')) },
        label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    )
}

@Composable
private fun ResultRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

private fun safeFileName(name: String): String =
    name.trim().replace(Regex("[^A-Za-z0-9áéíóúÁÉÍÓÚñÑ_-]+"), "_").ifBlank { "Trabajo_niveles" }

private fun persistSaved(context: Context, items: List<Calculation>) {
    val array = JSONArray()
    items.forEach { c ->
        val pts = JSONArray()
        c.points.forEach { p -> pts.put(JSONObject().put("distance", p.distance).put("level", p.level)) }
        array.put(JSONObject().apply {
            put("name", c.name); put("a", c.a); put("b", c.b); put("distance", c.distance)
            put("excavationA", c.excavationA); put("excavationB", c.excavationB)
            put("finalA", c.finalA); put("finalB", c.finalB); put("difference", c.difference)
            put("slopePercent", c.slopePercent); put("points", pts); put("pointMode", c.pointMode)
        })
    }
    context.getSharedPreferences("nivel_data", Context.MODE_PRIVATE).edit().putString("saved_jobs", array.toString()).apply()
}

private fun loadSaved(context: Context): List<Calculation> {
    val raw = context.getSharedPreferences("nivel_data", Context.MODE_PRIVATE).getString("saved_jobs", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val ptsJson = o.optJSONArray("points") ?: JSONArray()
            val pts = (0 until ptsJson.length()).map { j ->
                val p = ptsJson.getJSONObject(j); PointLevel(p.getDouble("distance"), p.getDouble("level"))
            }
            Calculation(o.optString("name"), o.getDouble("a"), o.getDouble("b"), o.getDouble("distance"),
                o.getDouble("excavationA"), o.getDouble("excavationB"), o.getDouble("finalA"),
                o.getDouble("finalB"), o.getDouble("difference"), o.getDouble("slopePercent"), pts, o.optString("pointMode", if (pts.size > 1) "uniform" else "single"))
        }
    } catch (_: Exception) { emptyList() }
}

private fun writePdf(context: Context, uri: Uri, c: Calculation) {
    val doc = PdfDocument()
    val pageWidth = 595; val pageHeight = 842
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f }
    var pageNumber = 0
    var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, ++pageNumber).create())
    var canvas = page.canvas
    var y = 52f
    fun newPage() {
        doc.finishPage(page)
        page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, ++pageNumber).create())
        canvas = page.canvas; y = 52f
    }
    fun line(text: String, bold: Boolean = false) {
        if (y > 780f) newPage()
        paint.typeface = if (bold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
        canvas.drawText(text.take(88), 42f, y, paint); y += 23f
    }
    line("REPORTE DE CALCULO DE NIVELES", true)
    line("Trabajo: ${c.name}")
    line("Cota conocida A: ${fmt(c.a)} m")
    line("Cota conocida B: ${fmt(c.b)} m")
    line("Distancia horizontal: ${fmt(c.distance)} m")
    line("Excavacion en A: ${fmt(c.excavationA)} m")
    line("Excavacion en B: ${fmt(c.excavationB)} m")
    line("Nivel terminado A: ${fmt(c.finalA)} m")
    line("Nivel terminado B: ${fmt(c.finalB)} m")
    line("Desnivel A a B: ${fmt(c.difference)} m")
    line("Pendiente: ${fmt(c.slopePercent)} %")
    y += 12f; line("PUNTOS INTERMEDIOS", true)
    line("No.     Distancia desde A (m)     Nivel (m)", true)
    c.points.forEachIndexed { i, p -> line("${i + 1}          ${fmt(p.distance)}                    ${fmt(p.level)}") }
    paint.textSize = 9f
    canvas.drawText("Generado por Calculadora de niveles - Pagina $pageNumber", 42f, 810f, paint)
    doc.finishPage(page)
    context.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }
        ?: throw IllegalStateException("No se pudo abrir el archivo de destino")
    doc.close()
}

private fun writeExcel(context: Context, uri: Uri, c: Calculation) {
    val rows = mutableListOf<List<String>>()
    rows += listOf("REPORTE DE CALCULO DE NIVELES")
    rows += listOf("Trabajo", c.name)
    rows += listOf("Cota conocida A (m)", fmt(c.a))
    rows += listOf("Cota conocida B (m)", fmt(c.b))
    rows += listOf("Distancia horizontal (m)", fmt(c.distance))
    rows += listOf("Excavacion en A (m)", fmt(c.excavationA))
    rows += listOf("Excavacion en B (m)", fmt(c.excavationB))
    rows += listOf("Nivel terminado A (m)", fmt(c.finalA))
    rows += listOf("Nivel terminado B (m)", fmt(c.finalB))
    rows += listOf("Desnivel A a B (m)", fmt(c.difference))
    rows += listOf("Pendiente (%)", fmt(c.slopePercent))
    rows += listOf("")
    rows += listOf("Punto", "Distancia desde A (m)", "Nivel intermedio (m)")
    c.points.forEachIndexed { i, p -> rows += listOf((i + 1).toString(), fmt(p.distance), fmt(p.level)) }

    fun xmlEscape(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")
    fun col(n: Int): String {
        var x = n + 1; var out = ""
        while (x > 0) { val r = (x - 1) % 26; out = ('A'.code + r).toChar() + out; x = (x - 1) / 26 }
        return out
    }
    val sheetRows = rows.mapIndexed { ri, row ->
        val cells = row.mapIndexed { ci, value ->
            val ref = "${col(ci)}${ri + 1}"
            val numeric = value.toDoubleOrNull()
            if (numeric != null) """<c r="$ref"><v>$value</v></c>"""
            else """<c r="$ref" t="inlineStr"><is><t>${xmlEscape(value)}</t></is></c>"""
        }.joinToString("")
        """<row r="${ri + 1}">$cells</row>"""
    }.joinToString("")
    val sheet = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>$sheetRows</sheetData></worksheet>""".trimIndent()

    val entries = linkedMapOf(
        "[Content_Types].xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
            <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
            <Default Extension="xml" ContentType="application/xml"/>
            <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
            <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
            </Types>""".trimIndent(),
        "_rels/.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
            <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
            </Relationships>""".trimIndent(),
        "xl/workbook.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
            <sheets><sheet name="Niveles" sheetId="1" r:id="rId1"/></sheets></workbook>""".trimIndent(),
        "xl/_rels/workbook.xml.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
            <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
            </Relationships>""".trimIndent(),
        "xl/worksheets/sheet1.xml" to sheet
    )
    context.contentResolver.openOutputStream(uri)?.use { output ->
        ZipOutputStream(output).use { zip ->
            entries.forEach { (name, content) ->
                zip.putNextEntry(ZipEntry(name))
                zip.write(content.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
        }
    } ?: throw IllegalStateException("No se pudo abrir el archivo de destino")
}
