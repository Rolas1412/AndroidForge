# Calculadora de Niveles de Excavación — Versión 3

Aplicación Android nativa en Kotlin y Jetpack Compose.

## Funciones
- Captura de cotas conocidas A y B, distancia horizontal y excavaciones independientes en ambos extremos.
- Cálculo de niveles terminados, desnivel firmado A→B y pendiente porcentual.
- Tres modos de puntos intermedios: un punto a distancia indicada desde A, varios puntos a distancias iguales o varias distancias manuales medidas horizontalmente desde A.
- Validación de distancias manuales (deben estar dentro del tramo y no repetirse) y orden automático ascendente.
- Interpolación lineal de los niveles intermedios.
- Gráfico del perfil longitudinal: cotas originales en naranja y perfil excavado en verde, con marcadores de puntos intermedios.
- Guardar, abrir y eliminar trabajos localmente en el teléfono.
- Compatibilidad de lectura con trabajos guardados por la versión 2.
- Exportación del cálculo y de todos los puntos a Excel (.xlsx) y PDF. El PDF crea páginas adicionales si la tabla es larga.

## Fórmulas
- Nivel terminado A = Cota A − Excavación A.
- Nivel terminado B = Cota B − Excavación B.
- Desnivel A→B = Nivel terminado B − Nivel terminado A.
- Pendiente (%) = (Desnivel A→B / Distancia horizontal) × 100.
- Nivel intermedio = Nivel terminado A + Desnivel × (distancia desde A / distancia total).

## Construcción del APK
El ZIP contiene el código fuente Android (no un APK). Súbelo a AndroidForge con plataforma **Android (APK)** y variante **Auto**. Al finalizar el flujo de GitHub Actions, descarga el artefacto APK generado. Si el servicio reporta un error, consulta el registro del workflow para identificar el motivo.

Antes de utilizar resultados en obra, comprueba los cálculos con casos de control y las especificaciones del proyecto.
