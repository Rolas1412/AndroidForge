# Calculadora de Niveles de Excavación — versión 4.0

Proyecto Android nativo en Kotlin + Jetpack Compose.

## Funciones conservadas de la versión 3
- Cálculo de niveles terminados en A y B, desnivel y pendiente.
- Puntos intermedios en modo único, distancias iguales o distancias manuales.
- Gráfico del perfil longitudinal y tabla de niveles.
- Guardado local de trabajos y exportación a Excel/PDF.

## Nuevo en la versión 4
### Módulo independiente: COTA DE EQUIPO
- La cota de equipo es obligatoria.
- Se ingresa exactamente uno de estos datos: cota objetivo o profundidad requerida.
- Si se ingresa cota objetivo, calcula profundidad requerida.
- Si se ingresa profundidad requerida, calcula cota objetivo.
- Opcionalmente se puede ingresar cota de terreno natural o profundidad del terreno natural medida desde la cota de equipo.
- Con terreno natural calcula la profundidad requerida desde el terreno natural.
- La excavación actual se mide desde el terreno natural original; cuando se proporciona también el dato de terreno natural, calcula la excavación faltante.
- El módulo no comparte campos ni resultados con la calculadora de perfil.

## Icono
Se incorporó un icono de excavadora y equipo topográfico para el launcher Android.

## Compilación
Abrir el proyecto en Android Studio o subir este ZIP a AndroidForge y seleccionar Android APK. El proyecto usa compileSdk 35, minSdk 23 y Java 17.
